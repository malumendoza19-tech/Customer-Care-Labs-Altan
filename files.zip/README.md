# Customer Care Skills Lab – Altán Redes

Simulador de entrenamiento para agentes de atención y soporte técnico de los OMVs.  
Acceso público, sin login, sin API Key visible para los usuarios.

---

## Estructura del proyecto

```
altan-lab/
├── index.html                  ← Simulador completo (una sola página)
├── netlify.toml                ← Configuración de Netlify
├── netlify/
│   └── functions/
│       └── proxy.js            ← Proxy seguro (guarda la key en el servidor)
└── README.md
```

---

## Despliegue en Netlify (gratis, 5 minutos)

### Paso 1 — Subir a GitHub
1. Crea un repositorio nuevo en github.com (puede ser privado o público)
2. Sube los 4 archivos manteniendo la estructura de carpetas

### Paso 2 — Conectar con Netlify
1. Ve a **netlify.com** → Log in (puedes usar tu cuenta de GitHub)
2. Haz clic en **"Add new site"** → **"Import an existing project"**
3. Conecta tu repositorio de GitHub
4. En "Build settings": déjalo todo en blanco (ya está configurado en `netlify.toml`)
5. Haz clic en **"Deploy site"**

### Paso 3 — Agregar la API Key (el paso clave)
1. En tu sitio de Netlify ve a: **Site configuration → Environment variables**
2. Haz clic en **"Add a variable"**
3. Key: `ANTHROPIC_API_KEY`
4. Value: tu API key de Anthropic (`sk-ant-api03-...`)
5. Haz clic en **"Save"**
6. Ve a **Deploys → Trigger deploy → Deploy site** para que aplique

### Paso 4 — Compartir el link
Netlify te dará una URL como: `https://tu-nombre.netlify.app`  
Esa URL es pública. Cualquier agente puede entrar y practicar sin necesidad de nada más.

---

## ¿Por qué Netlify y no GitHub Pages?

GitHub Pages sirve archivos estáticos únicamente.  
El simulador necesita llamar a la API con una key secreta — si la key estuviera en el HTML, cualquiera podría verla en el código fuente.

Netlify Functions permite tener un pequeño servidor (gratis) que guarda la key de forma segura y actúa como intermediario. El usuario solo ve el simulador, nunca la key.

---

## Plan gratuito de Netlify incluye:
- ✅ 125,000 llamadas a Functions por mes
- ✅ Dominio personalizable (`tu-empresa.netlify.app`)
- ✅ HTTPS automático
- ✅ Sin límite de usuarios simultáneos

Para un equipo de agentes en entrenamiento, el plan gratuito es más que suficiente.

---

## Personalización

Para cambiar el nombre del OMV o agregar escenarios, edita `index.html`:
- Busca `QUICK` para modificar los escenarios rápidos
- Busca `PH` para editar las fases y opciones de cada paso
- Busca `Tu Telefonía` para cambiar el nombre genérico del servicio
